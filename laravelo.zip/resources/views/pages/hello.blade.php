@extends('layout.app')

@section('content')
"hello wowowowoworld"
@endsection
