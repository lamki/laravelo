<?php $__env->startSection('content'); ?>
"hello bitch"
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelo\resources\views/hello.blade.php ENDPATH**/ ?>