<?php $__env->startSection('content'); ?>
    <h3>This is a post page</h3>
    <?php if(count($post) > 0): ?>
        <?php $__currentLoopData = $post; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="well">
                <h3><a href="/posts/<?php echo e($pst->id); ?>"><?php echo e($pst->title); ?></a></h3>
                <small>at : <?php echo e($pst->created_at); ?></small>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <h1>No Post</h1>
    <?php endif; ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelo\resources\views/posts/index.blade.php ENDPATH**/ ?>