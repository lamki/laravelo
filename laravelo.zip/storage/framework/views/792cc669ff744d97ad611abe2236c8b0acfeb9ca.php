<?php $__env->startSection('content'); ?>

<h1><?php echo e($title); ?></h1>
<br>
Hello this is the index page!

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelo\resources\views/index.blade.php ENDPATH**/ ?>