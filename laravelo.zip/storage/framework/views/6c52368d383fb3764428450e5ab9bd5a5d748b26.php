<?php $__env->startSection('content'); ?>
    <h1><?php echo e($posts->title); ?></h1><hr>
    <p><?php echo e($posts->body); ?></p>
    <a href="/posts/<?php echo e($posts->id); ?>/edit" class="btn btn-primary">Edit</a>
    <?php echo Form::open(['action' => ['PostController@destroy', $posts->id], 'method' => 'DELETE', 'class' => 'float-right']); ?>

        <?php echo e(Form::hidden('method', 'DELETE')); ?>

        <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelo\resources\views/posts/show.blade.php ENDPATH**/ ?>