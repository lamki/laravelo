<?php $__env->startSection('content'); ?>
<h1><?php echo e($title); ?></h1>
<h4>Our Services Include</h4>
<?php if(count($content) > 0): ?>
    <ul class="list-group">
    <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="list-group-item"><?php echo e($cont); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelo\resources\views/pages/service.blade.php ENDPATH**/ ?>